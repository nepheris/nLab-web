Archive imbriquee de demonstration.
