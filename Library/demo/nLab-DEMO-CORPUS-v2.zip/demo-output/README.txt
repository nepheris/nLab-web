Dossier de sortie logique de demonstration. Sur le web, les resultats utilisent les Telechargements du navigateur. Le navigateur ne peut pas imposer silencieusement un dossier local precis.
