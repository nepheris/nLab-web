# nLab DEMO CORPUS v2

Jeu de fichiers 100 % synthetiques destine aux tests de nLab PDF Studio et des autres applications nLab.

- demo-input/ : corpus a charger ;
- demo-output/ : destination logique ;
- docs/expected-results.json : cas de test.
