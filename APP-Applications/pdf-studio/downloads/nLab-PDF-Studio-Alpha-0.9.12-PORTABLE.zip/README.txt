nLab PDF Studio — Alpha 0.9.12 TEST / RC
Cette version n'est pas CURRENT.

Configuration :
- config/user-config.json
- config/stamps-v3.json
- config/google-auth.example.json

OAuth Google nécessite un Client ID Web. Aucun client secret ne doit être embarqué.
Les P12/PFX et mots de passe restent locaux.
Le package reste local-first mais dépend encore de bibliothèques CDN.
