nLab PDF Studio - Jeu de démonstration public v1
Aucune donnée personnelle réelle.

Contenu :
- demo-texte.pdf : PDF texte multipage
- demo-formulaire.pdf : PDF AcroForm (texte, case, liste)
- demo-image.png : image de test
- demo-document.docx : document Word de test
- demo-tableur.xlsx : classeur Excel de test
- demo-data.csv / demo-data.json / demo-notes.txt

Objectifs :
- tester ouverture / navigation / annotations
- image -> PDF et PDF -> image
- formulaires PDF
- DOCX et tableurs de démonstration
- classement, renommage et ZIP
